GAMER NAMER - web based gaming api interface

Introduction
    This is my finale project for the CS50 harvard course,
    As a gamer I've often ran into the problem that in order to get
    data about my account I often need to log-in to my game of choise.
    so I started looking into how to us gaming related apis to get data without
    entering my games...
    I've built GAMER NAMER as a modular tool so that adding a new game API should be pretty quick.

Main
    Gamer Namer is a web based platform to help gamers seek data by inputting their gamer-tag,
    I've created this project as a Proof of concept, using RIOT and Mojang API to get data
    about players from the popular games League Of Legends and Minecraft.
    Currently you need to register as a user which saves your username and password hash in "users" table
    in the games.db afterwards letting you see the history of queries you've already made.

Built with:
    Flask - python
    Javascript
    HTML
    CSS

Errors that could occur:
 I didn't get a permemnant license (I'm using the free version) for the API_KEY from RIOT so the API_KEY needs to be regenerated before use.

 shai benbasat
 Mrshibolet
